package packet;

public abstract class elementoMultimediale {
	String Titolo = "";

	public elementoMultimediale(String titolo) {
		super();
		Titolo = titolo;
	}
	
}
