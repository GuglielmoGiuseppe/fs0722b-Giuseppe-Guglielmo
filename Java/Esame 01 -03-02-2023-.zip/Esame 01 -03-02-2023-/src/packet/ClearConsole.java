package packet;

public class ClearConsole {

}
